package Crime_report;

import javax.swing.*;
import java.awt.*;

public class Crime_Report {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Crime Report Form");
        frame.setSize(450, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Title
        JLabel title = new JLabel("Crime Report Form", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBounds(80, 20, 280, 30);
        frame.add(title);

        // Name
        JLabel nameLabel = new JLabel("Your Name:");
        nameLabel.setBounds(40, 80, 120, 20);
        frame.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(170, 80, 220, 25);
        frame.add(nameField);

        // Contact Number
        JLabel contactLabel = new JLabel("Contact Number:");
        contactLabel.setBounds(40, 130, 120, 20);
        frame.add(contactLabel);

        JTextField contactField = new JTextField();
        contactField.setBounds(170, 130, 220, 25);
        frame.add(contactField);

        // Crime Type
        JLabel crimeLabel = new JLabel("Crime Type:");
        crimeLabel.setBounds(40, 180, 120, 20);
        frame.add(crimeLabel);

        String[] crimes = {"Select", "Theft", "Assault", "Cyber Crime", "Missing Person", "Other"};
        JComboBox<String> crimeBox = new JComboBox<>(crimes);
        crimeBox.setBounds(170, 180, 220, 25);
        frame.add(crimeBox);

        // Location
        JLabel locationLabel = new JLabel("Location:");
        locationLabel.setBounds(40, 230, 120, 20);
        frame.add(locationLabel);

        JTextField locationField = new JTextField();
        locationField.setBounds(170, 230, 220, 25);
        frame.add(locationField);

        // Description
        JLabel descLabel = new JLabel("Description:");
        descLabel.setBounds(40, 280, 120, 20);
        frame.add(descLabel);

        JTextArea descArea = new JTextArea();
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(descArea);
        scroll.setBounds(170, 280, 220, 100);
        frame.add(scroll);

        // Submit Button
        JButton submitBtn = new JButton("Submit Report");
        submitBtn.setBounds(150, 400, 150, 35);
        frame.add(submitBtn);

        // Submit Action
        submitBtn.addActionListener(e -> {
            String message = """
                             Report Submitted!
                             
                             Name: """ + nameField.getText() + "\n"
                    + "Contact: " + contactField.getText() + "\n"
                    + "Crime: " + crimeBox.getSelectedItem() + "\n"
                    + "Location: " + locationField.getText() + "\n"
                    + "Description: " + descArea.getText();

            JOptionPane.showMessageDialog(frame, message);
        });

        frame.setVisible(true);
    }
}